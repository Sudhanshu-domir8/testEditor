import javax.swing.*;

public class NotepadPlusJavaEditor extends JTextPane
{
    public static void main(String[] args)
	{   	
        new GUI().setVisible(true);
    }

}
